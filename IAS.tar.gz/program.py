arr1=["00100001","00000001","00001111","0000000000000000000000000000000000000000","00001010","00001001","00000101","00000110","00001011","00001100","00000000000000000000"]
#index     0          1         2                      3                              4           5         6           7          8          9             10                              
#index 0 has STOR M(X)
#index 1 has LOAD M(X)
#index 2 has JUMP+ M(X,0:19)
#index 3 has HALT
#index 4 has LOAD MQ
#index 5 has LOAD MQ,M(X)
#index 6 has ADD M(X)
#index 7 has SUB M(X)
#index 8 has MUL M(X)
#index 9 has DIV M(X)
#index 10 has NOP

M=['0']*1000 #Memory
AC=''
MBR=''
IR=''
MQ=''
IBR=''
MAR=0

a=int(input("Enter the number:"))             #Taking input from user
t='{0:040b}'.format(int(a))                    #Converting it into 40-bit binary 
M[100]='0000000000000000000000000000000000000000'
M[101]=t
M[102]='0000000000000000000000000000000000000001'

while(True):
    a1=['0']
    a2=['0']
    ins=""              #ins is used to store the 40-bit instruction format
    s=input("Enter the instructions:").split()   #s represents the input
    #print(s)
    if(s[0]=="HALT"):         #HALT means end
        ins=ins+arr1[3]
        M[5]=ins
        break
    if(s[3]=="NOP"):
        ins=ins+arr1[10]
    if(s[1]=="STOR"):                  #For STOR M(X)
        print("Opcode is :",arr1[0])  
        ins=ins+arr1[0]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp
    if(s[1]=="LOAD" and s[2][0:2]=='M('):   #For LOAD M(X)
        print("Opcode is :",arr1[1])
        ins=ins+arr1[1]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp
        
    if(s[1]=="JUMP+" and s[2][-5:-1]=="0:19"):    #For JUMP+ M(X,0:19)
        print("Opcode is :",arr1[2])
        ins=ins+arr1[2]
        temp='{0:012b}'.format(int(s[2][2:-6]))
        a1[0]=(s[2][2:-6])
        ins=ins+temp
    
    if((s[1])=="LOAD" and s[2][0:]=='MQ'):    #For LOAD MQ
        print("Opcode is :",arr1[4])
        ins=ins+arr1[4]
        ins=ins+"000000000000"
        
    if((s[1]=="LOAD" and s[2][0:4]=='MQ,M')):   #For LOAD MQ,M(X)
        print("Opcode is :",arr1[5])
        ins=ins+arr1[5]
        temp='{0:012b}'.format(int(s[2][5:-1]))
        a1[0]=(s[2][5:-1])
        ins=ins+temp
        
    if(s[1]=="ADD"):                         #For ADD M(X)
        print("Opcode is :",arr1[6])
        ins=ins+arr1[6]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp
        
    if(s[1]=="SUB"):                         #For SUB M(X)
        print("Opcode is :",arr1[7])
        ins=ins+arr1[7]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp
        
    if(s[1]=="MUL"):                         #For MUL M(X)
        print("Opcode is :",arr1[8])
        ins=ins+arr1[8]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp

    if(s[1]=="DIV"):                        #For DIV M(X)
        print("Opcode is :",arr1[9])
        ins=ins+arr1[9]
        temp='{0:012b}'.format(int(s[2][2:-1]))
        a1[0]=(s[2][2:-1])
        ins=ins+temp
      
    if(s[3]!="NOP"):
        if(s[3]=="STOR"):                   #For STOR M(X)
            print("Opcode is :",arr1[0])  
            ins=ins+arr1[0]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
    
        if(s[3]=="LOAD" and s[4][0]=='M'):   #For LOAD M(X)
            print("Opcode is :",arr1[1])
            ins=ins+arr1[1]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
        
        if(s[3]=="JUMP+" and s[4][-5:-1]=="0:19"):    #For JUMP+ M(X,0:19)
            print("Opcode is :",arr1[2])
            ins=ins+arr1[2]
            temp='{0:012b}'.format(int(s[4][2:-6]))
            a1[0]=(s[4][2:-6])
            ins=ins+temp
            
        if((s[3])=="LOAD" and s[2][0:]=='MQ'):    #For LOAD MQ
            print("Opcode is :",arr1[4])
            ins=ins+arr1[4]
            
        if((s[3]=="LOAD" and s[4][0:4]=='MQ,M')):  #For LOAD MQ,M(X)
            print("Opcode is :",arr1[5])
            ins=ins+arr1[5]
            temp='{0:012b}'.format(int(s[4][5:-1]))
            a2[0]=(s[4][5:-1])
            ins=ins+temp 
        if(s[3]=="ADD"):                         #For ADD M(X)
            print("Opcode is :",arr1[6])
            ins=ins+arr1[6]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
        if(s[3]=="SUB"):                        #For SUB M(X)
            print("Opcode is :",arr1[7])
            ins=ins+arr1[7]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
        if(s[3]=="MUL"):                        #For MUL M(X)
            print("Opcode is :",arr1[8])
            ins=ins+arr1[8]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
        if(s[3]=="DIV"):                        #For DIV M(X)
            print("Opcode is :",arr1[9])
            ins=ins+arr1[9]
            temp='{0:012b}'.format(int(s[4][2:-1]))
            a2[0]=(s[4][2:-1])
            ins=ins+temp
    
    print("40-bit instruction is :",ins)  
    if(s[0]!='HALT'):
        M[int(s[0])]=ins
    
    print("Instruction succesfully stored in memory and 40-bit :",M[int(s[0])])
PC=1   
while(True):
    MAR=PC  #MAR will take PC value
    MBR=M[MAR]
    IR=MBR[0:8]
    MAR=MBR[8:20]
    IBR=MBR[20:40]
    
    if(PC==5): #For HALT
        break
    
    if(IR=="00000001"):     #For load M(X)
        m="0b"
        MBR=M[int(m+MAR,2)]
        AC=MBR
        print("AC has :",AC)
    
    if(IR=="00001111"):      #For JUMP+ M(X,0:19)
        if(int(AC,2)>0):
            PC=1
        elif(int(AC,2)==0):
            PC=PC+1
    if(IR=="00001001"):      #For LOAD MQ,MX
        m="0b"
        MBR=M[int(m+MAR,2)]
        MQ=MBR
        print("MQ has :",MQ)
    
    if(IR=="00000101"):       #For ADD
        m="0b"
        MBR=M[int(m+MAR,2)]
        AC="0b"+AC
        ALU_ADD=bin(int(AC,2)+int(MBR,2))
        
        AC1=ALU_ADD[2:]
        AC1='{0:040b}'.format(int(AC1,2))
        AC=AC1
        print("After addition, AC has :",AC)
        
    if(IR=="00000110"):     #For SUB    
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_SUB=(int(AC,2)-int(MBR,2))
        if(ALU_SUB==0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[2:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC=AC2
            print("After subtraction, AC has :",AC)
        elif(ALU_SUB>0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[2:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC=AC2
            print("After subtraction, AC has :",AC)
        elif(ALU_SUB<0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[3:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC="1"+AC2[1:]
            print("After subtraction, AC has :",AC)
        
    if(IR=="00001011"):       #For MUL
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_MUL=bin(int(MQ,2)*int(MBR,2))
        temp='{0:080b}'.format(int(ALU_MUL,2))
        AC=temp[0:40]
        MQ=temp[40:80]
        print("After multiplication AC has:",AC)
        print("After multiplication MQ has:",MQ)
        
    if(IR=="00001100"):     #For DIV
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_DIVQ=bin(int(AC,2)//int(MBR,2))
        ALU_DIVR=bin(int(AC,2)%int(MBR,2))
        MQ='{0:040b}'.format(int(ALU_DIVQ,2))
        AC='{0:040b}'.format(int(ALU_DIVR,2))
        print("After division AC has:",AC)
        print("After division MQ has:",MQ)
        
    if(IR=="00100001"):     #for store
        m="0b"
        M[int(m+MAR,2)]=AC
        print("Data stored in",int(m+MAR,2),"is :",M[int(m+MAR,2)])
        
    if(IR=="00001010"):    #For lOAD MQ
        AC=MQ
        print("AC has:",AC)
    
    #For RHS
    IR=IBR[0:8]
    MAR=IBR[8:20]
    IBR=''
    
    if(IR=="00000001"):     #For load M(X)
        m="0b"
        MBR=M[int(m+MAR,2)]
        AC=MBR
        print("AC has :",AC)
    
    if(IR=="00001111"):      #For JUMP+ M(X,0:19)
        if(int(AC,2)>0):
            PC=1
        elif(int(AC,2)==0):
            PC=PC+1;    
        
    if(IR=="00001001"):      #For LOAD MQ,MX
        m="0b"
        MBR=M[int(m+MAR,2)]
        MQ=MBR
        print("MQ has :",MQ)
    
    if(IR=="00000101"):       #For ADD
        m="0b"
        MBR=M[int(m+MAR,2)]
        AC="0b"+AC
        ALU_ADD=bin(int(AC,2)+int(MBR,2))
        
        AC1=ALU_ADD[2:]
        AC1='{0:040b}'.format(int(AC1,2))
        AC=AC1
        print("After addition, AC has :",AC)
        
    if(IR=="00000110"):     #For SUB    
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_SUB=(int(AC,2)-int(MBR,2))
        if(ALU_SUB==0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[2:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC=AC2
            print("After subtraction, AC has :",AC)
        elif(ALU_SUB>0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[2:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC=AC2
            print("After subtraction, AC has :",AC)
        elif(ALU_SUB<0):
            ALU_SUB=bin(ALU_SUB)
            AC2=ALU_SUB[3:]
            AC2='{0:040b}'.format(int(AC2,2))
            AC="1"+AC2[1:]
            print("After subtraction, AC has :",AC)
    
    if(IR=="00001011"):       #For MUL
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_MUL=bin(int(MQ,2)*int(MBR,2))
        temp='{0:080b}'.format(int(ALU_MUL,2))
        AC=temp[0:40]
        MQ=temp[40:80]
        print("After multiplication AC has:",AC)
        print("After multiplication MQ has:",MQ)
        
    if(IR=="00001100"):     #For DIV
        m="0b"
        MBR=M[int(m+MAR,2)]
        ALU_DIVQ=bin((int(AC,2)//int(MBR,2)))
        ALU_DIVR=bin(int(AC,2)%int(MBR,2))
        MQ='{0:040b}'.format(int(ALU_DIVQ,2))
        AC='{0:040b}'.format(int(ALU_DIVR,2))
        print("After division AC has:",AC)
        print("After division MQ has:",MQ)
        
    if(IR=="00100001"):    #For store
        m="0b"
        M[int(m+MAR,2)]=AC
        print("Data stored in ",int(m+MAR,2) ,"is :",M[int(m+MAR,2)])
        
    if(IR=="00001010"):    #For lOAD MQ
        AC=MQ
        print("AC has:",AC)
    if(IR!="00001111"):
        PC=PC+1
print("Final answer is :",int(M[100],2))
