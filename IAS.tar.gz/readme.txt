In my program,I have implemented the sum of first n natural numbers in python

In the first line, the user has to enter n.
After entering the number.
User has to write the following instructions:

1 LOAD M(100) ADD M(101)
2 STOR M(100) NOP
3 LOAD M(101) SUB M(102)
4 STOR M(101) JUMP+ M(1,0:19)
HALT

The program which I have implemented makes use of loop(I am using a JUMP)
In 100 location, 0 is stored.
in 101 location, the number n is stored(in binary).
in 102 location, 1 is stored.

For eg:
If n is 10.

Firstly, 0 is sent to AC, then 10(i.e n) is added to it.
it is then stored in 100 location. Then we do 10-1 and store it in 101 location. This process continues until the data in 101 location is 0.

For eg:

User can implement this:

10                               
1 LOAD M(100) ADD M(101)
2 STOR M(100) NOP
3 LOAD M(101) SUB M(102)
4 STOR M(101) JUMP+ M(1,0:19)
HALT

The answer printed would be 55.

A screenshot is also shared in the input-output file.User can refer to that for better understanding.



