// C versions of programs 

//1. Addition
#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	int b;
	scanf("%d",&b);
	int c;
	c = a+b;
	printf("%d",c);
}

// 2. Subtraction

int main()
{
	int a;
	scanf("%d",&a);
	int b;
	scanf("%d",&b);
	int c;
	c = b-a;
	printf("%d",c);
}

// 3. Mulitiplication


int main()
{
	int a;
	scanf("%d",&a);
	int b;
	scanf("%d",&b);
	int c;
	c = a*b;
	printf("%d",c);
}

// 4. Division

int main()
{
	int a;
	scanf("%d",&a);
	int b;
	scanf("%d",&b);
	int c; 
	c = b/a;
	int d;
	d = b%a;
	printf("%d",c);
 	printf("%d",d);
}

//5. Sum of first n natural numbers
int main()
{
    int n;
    scanf("%d",&n);
    int sum = 0;
    while(n! = 0)
    {
        sum = sum + n;
        n--;
    }
    printf("%d",sum);
}
